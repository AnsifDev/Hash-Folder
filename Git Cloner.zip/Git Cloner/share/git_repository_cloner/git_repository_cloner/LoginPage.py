import os
from gi.repository import Adw, Gtk
from .DialogSSH import DialogSSH
from .util import ExtTerminal, parse_yml_file
from .HomePage import HomePage

@Gtk.Template(resource_path='/hashtag/linux/gitcloner/ui/login_page.ui')
class LoginPage(Gtk.Box):
    __gtype_name__ = 'LoginPage'

    login_git = Gtk.Template.Child()

    @Gtk.Template.Callback()
    def on_button_clicked(self, widget):
        if (widget == self.login_git):
            if os.system("gh auth status -h hostname") != 0:
                ExtTerminal(self.window).run("gh auth login -h github.com -p ssh -s admin:public_key -w", 1, self.on_terminal_task_performed)
            else: self.on_terminal_task_performed(1, 0)

    def on_terminal_task_performed(self, requestId, response):
        if response == 0:
            usrDat = parse_yml_file(os.path.expanduser("~/.config/gh/hosts.yml"))
            username = usrDat["github.com"]["user"]
            if os.path.exists(os.path.expanduser("~/.ssh/"+username)):
                self.complete_login(username)
            else:
                dg = DialogSSH(self.window, username, self.on_ssh_key_done)
                dg.present()
        else:
            dg = Adw.MessageDialog.new(self.window, "Login Failed", "Login attempt got failed. Please retry\nErr code:"+str(response))
            dg.add_response("ok", "OK")
            dg.present()

    def complete_login(self, username):
        self.window.connect_home_page(username)

    def on_ssh_key_done(self, dialog, keyname):
        print("Running")
        os.system("gh ssh-key add ~/.ssh/"+dialog.keyname.replace(" ","\\ ")+".pub -t \""+keyname+"\"")
        self.complete_login(dialog.keyname)
    
    def on_window_destroy(self, window):
        pass

    def __init__(self, window) -> None:
        super().__init__()
        self.window = window
