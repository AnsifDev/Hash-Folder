import json
import os
from gi.repository import Gtk, Adw, Gio
from .util import ExtTerminal, ch_port, rm_port
from .RepoListView import RepoListView
from .DialogEmail import DialogEmail

gtkbutton = """
<interface>
    <object class="GtkButton" id="custom_btn">
        <style>
            <class name="flat"/>
        </style>
        <property name="label">Choose Folder</property>
        <property name="icon-name">document-edit-symbolic</property>
        <property name="margin-top">8</property>
        <property name="halign">start</property>
        <property name="margin-bottom">8</property>
    </object>
</interface>
"""

@Gtk.Template(resource_path='/hashtag/linux/gitcloner/ui/home_page.ui')
class HomePage(Gtk.Box):
    __gtype_name__ = 'HomePage'

    avt = Gtk.Template.Child()
    greet = Gtk.Template.Child()
    repo_widget_list = Gtk.Template.Child()
    btn_email = Gtk.Template.Child()
    row_email = Gtk.Template.Child()
    stay_logged = Gtk.Template.Child()
    use_port = Gtk.Template.Child()
    repo_grp = Gtk.Template.Child()

    @Gtk.Template.Callback()
    def on_button_clicked(self, widget):
        print("Clicked")
        if widget == self.logout:
            dg = Adw.MessageDialog.new(self.window, "Logout?", "Are you going to logout?")
            dg.add_response("cancel", "Cancel")
            dg.add_response("logout", "Logout")
            dg.set_response_appearance("logout", 2)
            dg.set_response_appearance("cancel", 0)
            dg.connect("response", self.on_dialog_response)
            dg.present()
        elif widget == self.btn_email:
            dg = DialogEmail(self.window, self.on_email_dg_response)
            dg.present()
        elif widget == self.custom_btn:
            dg = Gtk.FileDialog()
            dg.set_title("Choose Folder")
            dg.set_modal(True)
            dg.set_initial_folder(Gio.File.new_for_path(self.home))
            dg.select_folder(self.window, None, self.on_folder_choosed, "Custom")

    def on_email_dg_response(self, widget, email):
        if email:
            self.row_email.set_subtitle(email)
            self.acc_config["email"] = email

    def on_dialog_response(self, widget, response):
        if response == "logout": 
            os.system("gh auth logout -h github.com")
            self.window.connect_login_page()
        elif response == "config":
            DialogEmail(self.window, self.on_email_dg_response).present()

    @Gtk.Template.Callback()
    def on_switch_state_changed(self, widget, state):
        if self.use_port == widget:
            self.acc_config["use_port"] = state
            if state: ch_port()
            else: rm_port()

    def on_checked_changed(self, widget):
        if not widget.get_active(): return
        match widget:
            case self.default_folder.btn: self.acc_config["folder"] = "default"
            case self.custom_folder.btn:
                self.acc_config["folder"] = "custom"
                if "custom_folder" not in self.acc_config: 
                    dg = Gtk.FileDialog()
                    dg.set_title("Choose Folder")
                    dg.set_modal(True)
                    dg.set_initial_folder(Gio.File.new_for_path(self.home))
                    dg.select_folder(self.window, None, self.on_folder_choosed, "Custom")
            case self.ask_folder.btn: self.acc_config["folder"] = "ask"

    def refresh(self, username):
        self.username = username
        self.avt.set_text(username)
        self.greet.set_label("Hey "+username)
        self.logout.set_visible(True)
        
        filename = self.cache_location+"repos.json"
        os.system("gh repo list --json name --json id --json visibility --json diskUsage --json nameWithOwner > "+filename)
        file = open(filename)
        json_str = file.read()
        file.close()
        if json_str == "": json_str = "[]"
        self.repoList = json.loads(json_str)

        filename = self.config_location+"accounts.json"
        if os.path.exists(filename):
            file = open(filename)
            self.accounts = json.loads(file.read())
            file.close()
        else: self.accounts = {}

        self.acc_config = None
        if username in self.accounts:
            self.acc_config = self.accounts[username]
        else:
            self.acc_config = {
                "stay_logged": False,
                "use_port": False,
                "folder": "default",
                "local_repo": {}
            }
            self.accounts[username] = self.acc_config

        for obj in self.repoList:
            if obj["id"] in self.acc_config["local_repo"]:
                if os.path.exists(self.acc_config["local_repo"][obj["id"]]):
                    obj["local"] = self.acc_config["local_repo"][obj["id"]]
                else: self.acc_config["local_repo"].pop(obj["id"])

        i = 1
        while i < len(self.repoList):
            j = i
            while j > 0:
                if self.repoList[j]["name"] < self.repoList[j-1]["name"]:
                    self.repoList.insert(j-1, self.repoList.pop(j))
                else: break
                j -= 1
            i += 1

        listview = RepoListView(self.repoList)
        listview.set_title("Repositories")
        listview.build("name", "visibility")
        listview.set_on_row_selected(self.on_row_selected)
        listview.set_on_open_clicked(self.on_row_open_clicked)
        self.repo_widget_list.set_child(listview)
        self.listview = listview

        self.default_folder.set_subtitle(self.home+username)
        
        self.stay_logged.set_active(self.acc_config["stay_logged"])
        self.use_port.set_active(self.acc_config["use_port"])
        if "email" in self.acc_config: self.row_email.set_subtitle(self.acc_config["email"])
        match self.acc_config["folder"]:
            case "default": self.default_folder.btn.set_active(True)
            case "custom": self.custom_folder.btn.set_active(True)
            case "ask": self.ask_folder.btn.set_active(True)
        if "custom_folder" in self.acc_config: self.custom_folder.set_subtitle(self.acc_config["custom_folder"])

    def on_row_selected(self, widget, index):
        self.repo = self.repoList[index]
        match self.acc_config["folder"]:
            case "default": folder = os.path.join(self.home, self.username, self.repo["name"])
            case "custom": folder = os.path.join(self.acc_config["custom_folder"], self.repo["name"])
            case "ask": folder = None
        if folder: self.start_clone(folder)
        else:
            dg = Gtk.FileDialog()
            dg.set_title("Choose Folder")
            dg.set_modal(True)
            dg.set_initial_folder(Gio.File.new_for_path(self.home))
            dg.select_folder(self.window, None, self.on_folder_choosed, "Ask")

    def on_folder_choosed(self, widget, result, userdata):
        print(userdata)
        try:
            file = widget.select_folder_finish(result)
            folder = file.get_path()
            if userdata == "Ask": self.start_clone(folder)
            elif userdata == "Custom": 
                self.acc_config["custom_folder"] = folder
                self.custom_folder.set_subtitle(folder)
        except: 
            if userdata == "Custom":
                if self.custom_folder.btn.get_active():
                    self.default_folder.btn.set_active(True)

    def on_row_open_clicked(self, widget, index):
        folder = self.repoList[index]["local"]
        if os.path.exists(folder):
            launcher = Gtk.FileLauncher()
            launcher.set_file(Gio.File.new_for_path(folder))
            launcher.launch(self.window, None, None, None)
        else:
            dg = Adw.MessageDialog.new(self.window, "Folder Not Found")
            dg.add_response("ok", "OK")
            dg.present()
            self.acc_config["local_repo"].pop(self.repoList[index]["id"])
            self.repoList[index].pop("local")
            self.listview.refresh()

    def start_clone(self, folder):
        if "email" not in self.acc_config:
            dg = Adw.MessageDialog.new(self.window, "Error", "Git User Email is not configured")
            dg.add_response("cancel", "Cancel")
            dg.add_response("config", "Configure Now")
            dg.set_response_appearance("config", 1)
            dg.set_response_appearance("cancel", 0)
            dg.connect("response", self.on_dialog_response)
            dg.present()
            return
        if not os.path.exists(folder): os.makedirs(folder)
        self.acc_config["local_repo"][self.repo["id"]] = folder
        self.repo["local"] = folder
        self.listview.refresh()
        ExtTerminal(self.window).run("gh repo clone "+self.repo["name"]+" "+folder.replace(" ", "\\ "), 1, self.on_terminal_task_complete)

    def on_terminal_task_complete(self, requestId, response):
        if requestId == 1:
            if response == 0:
                os.system("git config -f "+self.repo["local"].replace(" ", "\\ ")+"/.git/config user.name \""+self.username+"\"")
                os.system("git config -f "+self.repo["local"].replace(" ", "\\ ")+"/.git/config user.email \""+self.acc_config["email"]+"\"") 
                launcher = Gtk.FileLauncher()
                launcher.set_file(Gio.File.new_for_path(self.repo["local"]))
                launcher.launch(self.window, None, None, None)
            else:
                dg = Adw.MessageDialog.new(self.window, "Clone Failed", "Err code: "+str(response))
                dg.add_response("ok", "OK")
                dg.present()

    def on_window_destroy(self, window):
        self.acc_config["stay_logged"] = self.stay_logged.get_state()

        if not self.stay_logged.get_state(): os.system("gh auth logout -h github.com")
        rm_port()

        filename = self.config_location+"accounts.json"
        file = open(filename, "w")
        file.write(json.dumps(self.accounts))
        file.close()

    def __init__(self, window) -> None:
        super().__init__()
        self.window = window
        self.logout = window.logout
        self.logout.connect("clicked", self.on_button_clicked)
        self.row_email.set_activatable_widget(self.btn_email)
        self.cache_location = os.path.expanduser("~/.cache/hashtag-gitcloner/")
        self.config_location = os.path.expanduser("~/.config/hashtag-gitcloner/")
        self.home = os.path.expanduser("~/")

        self.default_folder = RadioActionRow()
        self.default_folder.set_title("Use Default Folder")
        self.default_folder.btn.connect("toggled", self.on_checked_changed)
        self.repo_grp.add(self.default_folder)

        self.custom_folder = RadioActionRow()
        self.custom_folder.set_title("Use Custom Folder")
        self.custom_folder.btn.connect("toggled", self.on_checked_changed)
        self.repo_grp.add(self.custom_folder)

        self.ask_folder = RadioActionRow()
        self.ask_folder.set_title("Ask Each Time")
        self.ask_folder.btn.connect("toggled", self.on_checked_changed)
        self.repo_grp.add(self.ask_folder)

        builder = Gtk.Builder.new_from_string(gtkbutton, -1)
        self.custom_btn = builder.get_object("custom_btn")
        self.custom_btn.connect("clicked", self.on_button_clicked)
        self.custom_folder.add_suffix(self.custom_btn)

        self.custom_folder.btn.set_group(self.default_folder.btn)
        self.ask_folder.btn.set_group(self.default_folder.btn)

class RadioActionRow(Adw.ActionRow):
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)

        self.btn = Gtk.CheckButton()
        self.add_prefix(self.btn)
        self.set_activatable_widget(self.btn)
