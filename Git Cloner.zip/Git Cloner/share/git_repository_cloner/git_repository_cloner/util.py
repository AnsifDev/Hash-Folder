import os
import shlex
from threading import Thread
import time
from .portConfig import getConfigs, saveConfig
from gi.repository import Gtk, Adw, GLib, Vte, Gio

class ExtTerminal:
    task_running = False

    def __run_silent(self, cmd):
        #time.sleep(5)
        rt = os.system(cmd)
        GLib.idle_add(self.__on_run_complete, rt)

    def run(self, cmd, requestId, callback=None, silent=False):
        if self.__task_alive: return False
        self.__task_alive = True
        self.callback = callback
        self.requestId = requestId
        if silent:
            self.place_holder.set_child(self.label)
            t = Thread(target=self.__run_silent, args=[cmd])
            t.start()
            self.btn_copy.set_visible(False)
            self.btn_paste.set_visible(False)
        else:
            self.place_holder.set_child(self.vte)
            cmdArgs = shlex.split(cmd)
            self.vte.spawn_async(Vte.PtyFlags.DEFAULT, None, cmdArgs, None, GLib.SpawnFlags.DEFAULT, None, None, -1, None, None)
            self.btn_copy.set_visible(True)
            self.btn_paste.set_visible(True)
        self.win.present()
        return True
    
    def __on_terminal_exited(self, widget, response):
        self.__on_run_complete(response)

    def __on_run_complete(self, response):
        if not self.__task_alive: return 
        if self.callback != None: self.callback(self.requestId, response)
        self.__task_alive = False
        self.win.close()
    
    def __window_destroyed(self, window):
        self.__task_alive = False

    def __build_new_window(self, parent):
        builder = Gtk.Builder.new_from_resource("/hashtag/linux/gitcloner/ui/terminal_task.ui")
        win = builder.get_object("window")
        win.set_transient_for(parent)
        win.connect("close-request", self.__window_destroyed)

        self.place_holder = builder.get_object("place_holder")
        self.label = builder.get_object("task_label")

        self.btn_copy = builder.get_object("btn_copy")
        self.btn_copy.connect("clicked", self.__on_btn_clicked)

        self.btn_paste = builder.get_object("btn_paste")
        self.btn_paste.connect("clicked", self.__on_btn_clicked)

        self.vte = Vte.Terminal()
        self.vte.set_size_request(600, 450)
        self.vte.connect("child-exited", self.__on_terminal_exited)
        return win
    
    def __on_btn_clicked(self, widget):
        if widget == self.btn_copy: self.vte.copy_clipboard_format(Vte.Format.TEXT)
        elif widget == self.btn_paste: self.vte.paste_clipboard()

    def __init__(self, parent) -> None:
        self.win = self.__build_new_window(parent)
        self.parent = parent
        self.__task_alive = False
    
def parse_yml_file(filename):
    file = open(filename)
    lines = file.readlines()
    file.close()
    
    dictData = {}
    prevTabs = 0
    stack = [dictData]
    stackTop = 0
    for line in lines:
        if len(line.strip()) == 0: continue

        tabs = 0
        for character in line:
            if (character != "\t"): break
            tabs += 1
        
        diff = prevTabs - tabs
        if diff > 1 or diff < -1: print("Err in yml script")

        result = line.strip().split(':')
        key = result[0].strip()
        if len(result) > 1: value = result[1].strip()
        else: value = ""

        print(key, value, stackTop, prevTabs, tabs, len(stack))

        if prevTabs > tabs:
            stackTop -= prevTabs-tabs
        
        if value == "":
            value = {}
            stack[stackTop][key] = value
            stackTop += 1
            stack.append(value)
        else: stack[stackTop][key] = value

        prevTabs = tabs
    
    print(dictData)
    return dictData

def ch_port():
    configurations = getConfigs()

    if "github.com" in configurations: configurations["github.com"].update([("HostName", "ssh.github.com"), ("Port", "443")])
    else: configurations["github.com"] = {
        "HostName": "ssh.github.com",
        "Port": "443"
    }

    saveConfig(configurations)

def rm_port():
    configurations = getConfigs()
    if "github.com" in configurations:
        if "Port" in configurations["github.com"]:
            configurations["github.com"].pop("Port")
            configurations["github.com"].pop("HostName")
        if len(configurations["github.com"]) == 0: configurations.pop("github.com")

    saveConfig(configurations)


#print(parse_yml_file("/home/darwin/.ssh/config"))

#Vte.Terminal.new()
