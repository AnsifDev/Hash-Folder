import os
from gi.repository import Adw
from gi.repository import Gtk

@Gtk.Template(resource_path='/hashtag/linux/gitcloner/ui/dg_install.ui')
class DialogInstall(Adw.Window):
    __gtype_name__ = 'DialogInstall'

    install_all = Gtk.Template.Child()
    install_git = Gtk.Template.Child()
    install_gh = Gtk.Template.Child()

    @Gtk.Template.Callback()
    def on_button_clicked(self, widget):
        pass
    
    def __init__(self, parent, **kwargs):
        super().__init__(**kwargs)

        self.set_transient_for(parent)
        if os.system("git --version") == 0:
            self.install_git.set_sensitive(False)
            self.install_git.set_label("Installed")
        if os.system("gh --version") == 0:
            self.install_gh.set_sensitive(False)
            self.install_gh.set_label("Installed")
